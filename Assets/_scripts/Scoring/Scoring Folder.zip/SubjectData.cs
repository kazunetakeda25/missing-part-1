using UnityEngine;
using System;
using System.Collections;

	
#region enums

public enum Episode
{
	Episode1,
	Episode2,
	Episode3
}

public enum PlayerRating 
{
	AboveAverage,
	Average,
	BelowAverage,
	NotYetEvaluated
}

public enum Gender 
{
	unspecified, 
	male, 
	female
};

public enum GameFeedbackAnswer 
{
	StronglyDisagree,
	Disagree,
	Neutral,
	Agree,
	StronglyAgree
}

public enum QuestionType 
{
	Short, //Short Self Review
	Long, //Long Self Review
	Feedback //Episode Feedback
}

public enum BiasType
{
	ConfirmationBias,
	FundamentalAttributionError
}

#endregion

public class SubjectData
{
	#region Class Declarations
	
	public class MyMugProfile
	{
		public string username = "Player";
		public int profilePicture = -1;
	}
	
	public class EpisodeFeedback
	{
		public int engagement;
		public int effort;
		public int challenge;
	}
	
	#endregion
	
	#region Regular Variables
	
	public string subjectID = "";
	public Gender subjectGender = Gender.male;
	public MyMugProfile mugProfile = new MyMugProfile();
	
	public BiasChoice E1V1BiasAnswer = BiasChoice.None;
	public BiasChoice E1V2BiasAnswer = BiasChoice.None;
	public BiasChoice E1V2BiasAnswer_2 = BiasChoice.None;
	public BiasChoice E1V3BiasAnswer = BiasChoice.None;
	public BiasChoice E1V4BiasAnswer = BiasChoice.None;
	public BiasChoice E2V5BiasAnswer = BiasChoice.None;
	public BiasChoice E2V6BiasAnswer = BiasChoice.None;
	public BiasChoice E2V7BiasAnswer = BiasChoice.None;
	public BiasChoice E3V8BiasAnswer = BiasChoice.None;
	public BiasChoice E3V9BiasAnswer = BiasChoice.None;
	public BiasChoice E3V10BiasAnswer = BiasChoice.None;
	
	private bool sentEp1SelfReviewMessage;
	private bool sentEp2SelfReviewMessage;
	private bool sentEp3SelfReviewMessage;
	
	#region Episode Scores & Feedback
	
	public EpisodeFeedback ep1Feedback = new EpisodeFeedback();
	public EpisodeFeedback ep2Feedback = new EpisodeFeedback();
	public EpisodeFeedback ep3Feedback = new EpisodeFeedback();
	
	public VignetteScore e1v1ExplorationScore = new VignetteScore();
	public VignetteScore e1v3ExplorationScore = new VignetteScore();
	public VignetteScore e2v7ExplorationScore = new VignetteScore();
	public VignetteScore e3v10ExplorationScore = new VignetteScore();
	
	public bool ep1FAEBlindspot;
	public bool ep1ConfBlindspot;
	public bool ep2FAEBlindspot;
	public bool ep2ConfBlindspot;
	public bool ep3FAEBlindspot;
	public bool ep3ConfBlindspot;
	
	#endregion	
	
	#endregion
	
	#region Variables with Properties	
	
	private PlayerRating confirmationBiasRatingEp1 = PlayerRating.NotYetEvaluated;
	public PlayerRating ConfirmationBiasRatingEp1
	{
		get{ return confirmationBiasRatingEp1; }
		set
		{
			confirmationBiasRatingEp1 = value;
			Message sendConfirmationBiasRatingEp1 = new Message_ReportCalculatedBiasScore(Episode.Episode1, BiasType.ConfirmationBias, value);
			//App.Instance().GetMessageManager().Trigger(sendConfirmationBiasRatingEp1);
		}
	}
	
	private PlayerRating fundamentalAttributionErrorRatingEp1 = PlayerRating.NotYetEvaluated;
	public PlayerRating FundamentalAttributionErrorRatingEp1
	{
		get{ return fundamentalAttributionErrorRatingEp1; }
		set
		{
			fundamentalAttributionErrorRatingEp1 = value;
			Message sendFAEBiasRatingEp1 = new Message_ReportCalculatedBiasScore(Episode.Episode1, BiasType.FundamentalAttributionError, value);
			//App.Instance().GetMessageManager().Trigger(sendFAEBiasRatingEp1);
		}
	}
	
	private PlayerRating confirmationBiasRatingEp2 = PlayerRating.NotYetEvaluated;
	public PlayerRating ConfirmationBiasRatingEp2
	{
		get{ return confirmationBiasRatingEp2; }
		set
		{
			confirmationBiasRatingEp2 = value;
			Message sendConfirmationBiasRatingEp2 = new Message_ReportCalculatedBiasScore(Episode.Episode2, BiasType.ConfirmationBias, value);
			//App.Instance().GetMessageManager().Trigger(sendConfirmationBiasRatingEp2);
		}
	}
	
	private PlayerRating fundamentalAttributionErrorRatingEp2 = PlayerRating.NotYetEvaluated;
	public PlayerRating FundamentalAttributionErrorRatingEp2
	{
		get{ return fundamentalAttributionErrorRatingEp2; }
		set
		{
			fundamentalAttributionErrorRatingEp2 = value;
			Message sendFAEBiasRatingEp2 = new Message_ReportCalculatedBiasScore(Episode.Episode2, BiasType.FundamentalAttributionError, value);
			//App.Instance().GetMessageManager().Trigger(sendFAEBiasRatingEp2);
		}
	}
	
	private PlayerRating confirmationBiasRatingEp3 = PlayerRating.NotYetEvaluated;
	public PlayerRating ConfirmationBiasRatingEp3
	{
		get{ return confirmationBiasRatingEp3; }
		set
		{
			confirmationBiasRatingEp3 = value;
			Message sendConfirmationBiasRatingEp3 = new Message_ReportCalculatedBiasScore(Episode.Episode3, BiasType.ConfirmationBias, value);
			//App.Instance().GetMessageManager().Trigger(sendConfirmationBiasRatingEp3);
		}
	}
	
	private PlayerRating fundamentalAttributionErrorRatingEp3 = PlayerRating.NotYetEvaluated;
	public PlayerRating FundamentalAttributionErrorRatingEp3
	{
		get{ return fundamentalAttributionErrorRatingEp3; }
		set
		{
			fundamentalAttributionErrorRatingEp3 = value;
			Message sendFAEBiasRatingEp3 = new Message_ReportCalculatedBiasScore(Episode.Episode3, BiasType.FundamentalAttributionError, value);
			//App.Instance().GetMessageManager().Trigger(sendFAEBiasRatingEp3);
		}
	}	
	
	#region Episode 1 Self Review
	
	private int ep1ConfirmationBiasAnswer1;
	public int Ep1ConfirmationBiasAnswer1
	{
		get{ return ep1ConfirmationBiasAnswer1; }
		set
		{
			ep1ConfirmationBiasAnswer1 = value;
		}
	}
	
	private int ep1ConfirmationBiasAnswer2;
	public int Ep1ConfirmationBiasAnswer2
	{
		get { return ep1ConfirmationBiasAnswer2; }
		set
		{
			ep1ConfirmationBiasAnswer2 = value;
		}
	}
	
	private int ep1FundamentalAttributionError1;
	public int Ep1FundamentalAttributionError1
	{
		get { return ep1FundamentalAttributionError1; }
		set
		{
			ep1FundamentalAttributionError1 = value;
		}
	}	
	
	private int ep1FundamentalAttributionError2;
	public int Ep1FundamentalAttributionError2
	{
		get { return ep1FundamentalAttributionError2; }
		set
		{
			if(!sentEp1SelfReviewMessage) {
				ep1FundamentalAttributionError2 = value;
				Message selfEvalMessage = QuestionReportingTools.GenerateSelfEvaluationAnswer(Episode.Episode1, this);
				//App.Instance().GetMessageManager().Trigger(selfEvalMessage);
				sentEp1SelfReviewMessage = true;
			}
		}
	}
	
	#endregion
	
	#region Episode 2 Self Review
	
	private int ep2ConfirmationBiasAnswer1;
	public int Ep2ConfirmationBiasAnswer1
	{
		get { return ep2ConfirmationBiasAnswer1; }
		set
		{ ep2ConfirmationBiasAnswer1 = value; }
	}
	
	private int ep2ConfirmationBiasAnswer2;
	public int Ep2ConfirmationBiasAnswer2
	{
		get { return ep2ConfirmationBiasAnswer2; }
		set { ep2ConfirmationBiasAnswer2 = value; }
	}
	
	private int ep2FundamentalAttributionError1;
	public int Ep2FundamentalAttributionError1
	{
		get { return ep2FundamentalAttributionError1; }
		set { ep2FundamentalAttributionError1 = value; }
	}	
	
	private int ep2FundamentalAttributionError2;
	public int Ep2FundamentalAttributionError2
	{
		get { return ep2FundamentalAttributionError2; }
		set
		{
			if(!sentEp2SelfReviewMessage) {
				ep2FundamentalAttributionError2 = value;
				Message selfEvalMessage = QuestionReportingTools.GenerateSelfEvaluationAnswer(Episode.Episode2, this);
				//App.Instance().GetMessageManager().Trigger(selfEvalMessage);
				sentEp2SelfReviewMessage = true;
			}
		}
	}
	
	#endregion
	
	#region Episode 3 Self Review Answers
	
	private int ep3ConfirmationBiasAnswer1;
	public int Ep3ConfirmationBiasAnswer1
	{
		get { return ep3ConfirmationBiasAnswer1; }
		set { ep3ConfirmationBiasAnswer1 = value; }
	}
	
	private int ep3ConfirmationBiasAnswer2;
	public int Ep3ConfirmationBiasAnswer2
	{
		get { return ep3ConfirmationBiasAnswer2; }
		set { ep3ConfirmationBiasAnswer2 = value; }
	}
	
	private int ep3FundamentalAttributionError1;
	public int Ep3FundamentalAttributionError1
	{
		get { return ep3FundamentalAttributionError1; }
		set { ep3FundamentalAttributionError1 = value; }
	}	
	
	private int ep3FundamentalAttributionError2;
	public int Ep3FundamentalAttributionError2
	{
		get { return ep3FundamentalAttributionError2; }
		set
		{
			if(!sentEp3SelfReviewMessage) {
				ep3FundamentalAttributionError2 = value;
				Message selfEvalMessage = QuestionReportingTools.GenerateSelfEvaluationAnswer(Episode.Episode3, this);
				//App.Instance().GetMessageManager().Trigger(selfEvalMessage);
				sentEp3SelfReviewMessage = true;
			}
		}
	}	
	
	#endregion
	
	#endregion
	
	//These are all our public Score Saving Actions
	
	public void ReportPlayerInfo() {
		Message sendPlayerInfo = new Message_ReportPlayerInfo(subjectGender, mugProfile.username, mugProfile.profilePicture);
		//App.Instance().GetMessageManager().Trigger(sendPlayerInfo);
	}
	
	public void SaveE1V1Data() 
	{
		e1v1ExplorationScore = VignetteScoreTools.GetVignetteScoreReport(Vignette.VignetteID.E1vTerrysApartmentSearch);
		VignetteScoreTools.DebugDumpVignetteDataToConsole(e1v1ExplorationScore);
		Message vignetteCompleteMessage = VignetteScoreTools.GenerateVignetteCompleteMessage(Vignette.VignetteID.E1vTerrysApartmentSearch, e1v1ExplorationScore);
		//App.Instance().GetMessageManager().Trigger(vignetteCompleteMessage);
	}
	
	public void SaveE1V3Data() 
	{
		e1v3ExplorationScore = VignetteScoreTools.GetVignetteScoreReport(Vignette.VignetteID.E1vHomeOfficeSearch);
		VignetteScoreTools.DebugDumpVignetteDataToConsole(e1v3ExplorationScore);
		Message vignetteCompleteMessage =  VignetteScoreTools.GenerateVignetteCompleteMessage(Vignette.VignetteID.E1vHomeOfficeSearch, e1v3ExplorationScore);
		//App.Instance().GetMessageManager().Trigger(vignetteCompleteMessage);
	}
	
	public void SaveE2V7Data() 
	{
		e2v7ExplorationScore = VignetteScoreTools.GetVignetteScoreReport(Vignette.VignetteID.E2vGPCOfficeSearch);
		VignetteScoreTools.DebugDumpVignetteDataToConsole(e1v3ExplorationScore);
		Message vignetteCompleteMessage = VignetteScoreTools.GenerateVignetteCompleteMessage(Vignette.VignetteID.E2vGPCOfficeSearch, e2v7ExplorationScore);
		//App.Instance().GetMessageManager().Trigger(vignetteCompleteMessage);
	}
	
	public void SaveE3V10Data() 
	{
		e3v10ExplorationScore = VignetteScoreTools.GetVignetteScoreReport(Vignette.VignetteID.E3vChrisBriefcaseSearch);
		VignetteScoreTools.DebugDumpVignetteDataToConsole(e3v10ExplorationScore);
		Message vignetteCompleteMessage = VignetteScoreTools.GenerateVignetteCompleteMessage(Vignette.VignetteID.E3vChrisBriefcaseSearch, e3v10ExplorationScore);
		//App.Instance().GetMessageManager().Trigger(vignetteCompleteMessage);
	}
		
	public void ReportQuestionAnswer(AARScreen.Question question, int index) 
	{
		switch(question) {
		case AARScreen.Question.ConfirmationBiasE1Q1:
			Ep1ConfirmationBiasAnswer1 = index;
			break;
		case AARScreen.Question.ConfirmationBiasE1Q2:
			Ep1ConfirmationBiasAnswer2 = index;
			break;
		case AARScreen.Question.FundamentalAttributionErrorE1Q1:
			Ep1FundamentalAttributionError1 = index;
			break;
		case AARScreen.Question.FundamentalAttributionErrorE1Q2:
			Ep1FundamentalAttributionError2 = index;
			break;
		}
	}
	
	private int CalculateBiasInt(BiasChoice biasChoice) {
		//Turn a Bias Choice into an Int.  If Biased = 1, if Ambigious = 0;
		if(biasChoice == BiasChoice.Ambiguous)
			return 0;
		else
			return 1;
	}
	
	public void ReportSimpleEpisode1Score() {
		Debug.Log("Sending Final Episode 1 Score");
		
		int faeQuestionScore = CalculateBiasInt(E1V2BiasAnswer_2) + CalculateBiasInt(E1V4BiasAnswer);
		int maxFAEQuestionScore = 2;
		int confirmationQuestionScore = CalculateBiasInt(E1V1BiasAnswer) + CalculateBiasInt(E1V3BiasAnswer);
		int maxConfirmationQuestionScore = 2;
		
		float confirmationSearchingScore = (e1v3ExplorationScore.AmbigiousBiasScore + e1v1ExplorationScore.AmbigiousBiasScore) / 2;
		
		Message episodeCompleteMessage = new Message_SimpleEpisodeScores(
			Episode.Episode1, 
			faeQuestionScore, 
			maxFAEQuestionScore,
			confirmationQuestionScore,
			maxConfirmationQuestionScore,
			confirmationSearchingScore,
			ep1FAEBlindspot, 
			ep1ConfBlindspot);
		
		//App.Instance().GetMessageManager().Trigger(episodeCompleteMessage);
	}
	
	public void ReportSimpleEpisode2Score() {
		Debug.Log("Sending Final Episode 2 Score");
		
		int faeQuestionScore = CalculateBiasInt(E2V5BiasAnswer) + CalculateBiasInt(E2V6BiasAnswer);
		int maxFAEQuestionScore = 2;
		int confimrationQuestionScore = CalculateBiasInt(E2V7BiasAnswer);
		int maxConfirmationQuestionScore = 1;
		
		float confimationSearchingScore = (e2v7ExplorationScore.AmbigiousBiasScore);
		
		Message episodeCompleteMessage = new Message_SimpleEpisodeScores(
			Episode.Episode2,
			faeQuestionScore, 
			maxFAEQuestionScore,
			confimrationQuestionScore,
			maxConfirmationQuestionScore,
			confimationSearchingScore,
			ep2FAEBlindspot, 
			ep2ConfBlindspot);
		
		//App.Instance().GetMessageManager().Trigger(episodeCompleteMessage);
	}
	
	public void ReportSimpleEpisode3Score() {
		Debug.Log("Sending Final Episode 3 Score");
		
		int faeQuestionScore = CalculateBiasInt(E3V8BiasAnswer) + CalculateBiasInt(E3V9BiasAnswer);
		int maxFAEQuestionScore = 2;
		int confimrationQuestionScore = CalculateBiasInt(E3V10BiasAnswer);
		int maxConfirmationQuestionScore = 1;
		
		float confimationSearchingScore = (e3v10ExplorationScore.AmbigiousBiasScore);
		
		Message episodeCompleteMessage = new Message_SimpleEpisodeScores(
			Episode.Episode3,
			faeQuestionScore, 
			maxFAEQuestionScore,
			confimrationQuestionScore,
			maxConfirmationQuestionScore,
			confimationSearchingScore,
			ep3FAEBlindspot, 
			ep3ConfBlindspot);
		
		//App.Instance().GetMessageManager().Trigger(episodeCompleteMessage);
	}
	
}
