using UnityEngine;
using System.Collections;

public class QuestionReportingTools {
	
	//BackCODE: This class is for gathering and generating Question Scoring Data.  These are mostly called from SubjectData
	
	public static Message GenerateFeedbackQuestionMessage(Episode episode, SubjectData.EpisodeFeedback epFeedback) 
	{
		
		return new Message_EpisodeFeedback(
			episode, 
			epFeedback.engagement,
			epFeedback.effort,
			epFeedback.challenge);
	}
	
	
	public static PlayerRating GetPlayerSelfRating(AARScreen.Question question, int index) 
	{
		PlayerRating selfRating = PlayerRating.NotYetEvaluated;
		switch(question) {
		case AARScreen.Question.ConfirmationBiasE1Q1:
			selfRating = ConvertPlayerSelfRating(QuestionType.Short, index);
			break;
		case AARScreen.Question.ConfirmationBiasE1Q2:
			selfRating = ConvertPlayerSelfRating(QuestionType.Long, index);
			break;
		case AARScreen.Question.FundamentalAttributionErrorE1Q1:
			selfRating = ConvertPlayerSelfRating(QuestionType.Short, index);
			break;
		case AARScreen.Question.FundamentalAttributionErrorE1Q2:
			selfRating = ConvertPlayerSelfRating(QuestionType.Long, index);
			break;
		case AARScreen.Question.ConfirmationBiasE2Q1:
			selfRating = ConvertPlayerSelfRating(QuestionType.Short, index);
			break;
		case AARScreen.Question.ConfirmationBiasE2Q2:
			selfRating = ConvertPlayerSelfRating(QuestionType.Long, index);
			break;
		case AARScreen.Question.FundamentalAttributionErrorE2Q1:
			selfRating = ConvertPlayerSelfRating(QuestionType.Short, index);
			break;
		case AARScreen.Question.FundamentalAttributionErrorE2Q2:
			selfRating = ConvertPlayerSelfRating(QuestionType.Long, index);
			break;
		case AARScreen.Question.ConfirmationBiasE3Q1:
			selfRating = ConvertPlayerSelfRating(QuestionType.Short, index);
			break;
		case AARScreen.Question.ConfirmationBiasE3Q2:
			selfRating = ConvertPlayerSelfRating(QuestionType.Long, index);
			break;
		case AARScreen.Question.FundamentalAttributionErrorE3Q1:
			selfRating = ConvertPlayerSelfRating(QuestionType.Short, index);
			break;
		case AARScreen.Question.FundamentalAttributionErrorE3Q2:
			selfRating = ConvertPlayerSelfRating(QuestionType.Long, index);
			break;
		default:
			Debug.LogError("Question Type incorrectly sent: " + question);
			break;
		}
		
		return selfRating;
	}
	
	
	private static string ConvertQuestionIndexToFeedbackAnswer(int index) 
	{
		string feedbackAnswer = "";
		switch(index) {
		case 0:
			feedbackAnswer = "Strongly Disagree";
			break;
		case 1:
			feedbackAnswer = "Disagree";
			break;
		case 2:
			feedbackAnswer = "Neutral";
			break;
		case 3:
			feedbackAnswer = "Agree";
			break;
		case 4:
			feedbackAnswer = "Strongly Agree";
			break;
		}
		return feedbackAnswer;
	}
	
	private static PlayerRating ConvertPlayerSelfRating(QuestionType type, int index) 
	{
		PlayerRating selfRating = PlayerRating.NotYetEvaluated;
		
		switch(type) 
		{
		case QuestionType.Short:
			if(index > 2)
			{
				selfRating = PlayerRating.BelowAverage;
			}
			else if(index == 2)
			{
				selfRating = PlayerRating.Average;
			}
			else
			{
				selfRating = PlayerRating.AboveAverage;
			}			
			break;
		case QuestionType.Long:
			if(index > 3)
			{
				selfRating = PlayerRating.BelowAverage;
			} 
			else if(index == 3)
			{
				selfRating = PlayerRating.Average;
			}
			else
			{
				selfRating = PlayerRating.AboveAverage;
			}			
			break;
		}
		
		return selfRating;
	}
	
	public static Message GenerateSelfEvaluationAnswer(Episode episode, SubjectData currentSubject)
	{
		Debug.Log("Generating Message to report self review for episode: " + episode);
		int selfReviewAnswerQ1 = 0;
		int selfReviewAnswerQ2 = 0;
		int selfReviewAnswerQ3 = 0;
		int selfReviewAnswerQ4 = 0;
		
		AARScreen.Question selfReviewQuestion1 = AARScreen.Question.None;
		AARScreen.Question selfReviewQuestion2 = AARScreen.Question.None;
		AARScreen.Question selfReviewQuestion3 = AARScreen.Question.None;
		AARScreen.Question selfReviewQuestion4 = AARScreen.Question.None;
		
		switch(episode) {
		case Episode.Episode1:
			selfReviewAnswerQ1 = currentSubject.Ep1ConfirmationBiasAnswer1;
			selfReviewAnswerQ2 = currentSubject.Ep1ConfirmationBiasAnswer2;
			selfReviewAnswerQ3 = currentSubject.Ep1FundamentalAttributionError1;
			selfReviewAnswerQ4 = currentSubject.Ep1FundamentalAttributionError2;
			selfReviewQuestion1 = AARScreen.Question.ConfirmationBiasE1Q1;
			selfReviewQuestion2 = AARScreen.Question.ConfirmationBiasE1Q2;
			selfReviewQuestion3 = AARScreen.Question.FundamentalAttributionErrorE1Q1;
			selfReviewQuestion4 = AARScreen.Question.FundamentalAttributionErrorE1Q2;
			break;
		case Episode.Episode2:
			selfReviewAnswerQ1 = currentSubject.Ep2ConfirmationBiasAnswer1;
			selfReviewAnswerQ2 = currentSubject.Ep2ConfirmationBiasAnswer2;
			selfReviewAnswerQ3 = currentSubject.Ep2FundamentalAttributionError1;
			selfReviewAnswerQ4 = currentSubject.Ep2FundamentalAttributionError2;
			selfReviewQuestion1 = AARScreen.Question.ConfirmationBiasE2Q1;
			selfReviewQuestion2 = AARScreen.Question.ConfirmationBiasE2Q2;
			selfReviewQuestion3 = AARScreen.Question.FundamentalAttributionErrorE2Q1;
			selfReviewQuestion4 = AARScreen.Question.FundamentalAttributionErrorE2Q2;
			break;
		case Episode.Episode3:
			selfReviewAnswerQ1 = currentSubject.Ep3ConfirmationBiasAnswer1;
			selfReviewAnswerQ2 = currentSubject.Ep3ConfirmationBiasAnswer2;
			selfReviewAnswerQ3 = currentSubject.Ep3FundamentalAttributionError1;
			selfReviewAnswerQ4 = currentSubject.Ep3FundamentalAttributionError2;
			selfReviewQuestion1 = AARScreen.Question.ConfirmationBiasE3Q1;
			selfReviewQuestion2 = AARScreen.Question.ConfirmationBiasE3Q2;
			selfReviewQuestion3 = AARScreen.Question.FundamentalAttributionErrorE3Q1;
			selfReviewQuestion4 = AARScreen.Question.FundamentalAttributionErrorE3Q2;			
			break;
		default:
			Debug.LogError("New Bias Self Eval Questions and Answers not yet setup for scoring.  You need to go into Question Reporting Tools and manually hook those up.");
			break;
		}
		
		string selfReview1 = GenerateSelfEvaluationString(selfReviewQuestion1);
		string selfReview2 = GenerateSelfEvaluationString(selfReviewQuestion2);
		string selfReview3 = GenerateSelfEvaluationString(selfReviewQuestion3);
		string selfReview4 = GenerateSelfEvaluationString(selfReviewQuestion4);
		
		return new Message_ReportSelfReviewScore(episode, selfReview1, selfReview2, selfReview3, selfReview4, selfReviewAnswerQ1, selfReviewAnswerQ2, selfReviewAnswerQ3, selfReviewAnswerQ4);
	}
	
	private static string GenerateSelfEvaluationString(AARScreen.Question question) 
	{
		string questionAndAnswerText;
		switch(question) 
		{
		case AARScreen.Question.ConfirmationBiasE1Q1:
			questionAndAnswerText = AARQuestionText.GetSelfReviewQuestionText(AARScreen.Question.ConfirmationBiasE1Q1);
			break;
		case AARScreen.Question.ConfirmationBiasE1Q2:
			questionAndAnswerText = AARQuestionText.GetSelfReviewQuestionText(AARScreen.Question.ConfirmationBiasE1Q2);
			break;
		case AARScreen.Question.FundamentalAttributionErrorE1Q1:
			questionAndAnswerText = AARQuestionText.GetSelfReviewQuestionText(AARScreen.Question.FundamentalAttributionErrorE1Q1);
			break;
		case AARScreen.Question.FundamentalAttributionErrorE1Q2:
			questionAndAnswerText = AARQuestionText.GetSelfReviewQuestionText(AARScreen.Question.FundamentalAttributionErrorE1Q2);
			break;
		case AARScreen.Question.ConfirmationBiasE2Q1:
			questionAndAnswerText = AARQuestionText.GetSelfReviewQuestionText(AARScreen.Question.ConfirmationBiasE2Q1);
			break;
		case AARScreen.Question.ConfirmationBiasE2Q2:
			questionAndAnswerText = AARQuestionText.GetSelfReviewQuestionText(AARScreen.Question.ConfirmationBiasE2Q2);
			break;
		case AARScreen.Question.FundamentalAttributionErrorE2Q1:
			questionAndAnswerText = AARQuestionText.GetSelfReviewQuestionText(AARScreen.Question.FundamentalAttributionErrorE2Q1);
			break;
		case AARScreen.Question.FundamentalAttributionErrorE2Q2:
			questionAndAnswerText = AARQuestionText.GetSelfReviewQuestionText(AARScreen.Question.FundamentalAttributionErrorE2Q2);
			break;
		case AARScreen.Question.ConfirmationBiasE3Q1:
			questionAndAnswerText = AARQuestionText.GetSelfReviewQuestionText(AARScreen.Question.ConfirmationBiasE3Q1);
			break;
		case AARScreen.Question.ConfirmationBiasE3Q2:
			questionAndAnswerText = AARQuestionText.GetSelfReviewQuestionText(AARScreen.Question.ConfirmationBiasE3Q2);
			break;
		case AARScreen.Question.FundamentalAttributionErrorE3Q1:
			questionAndAnswerText = AARQuestionText.GetSelfReviewQuestionText(AARScreen.Question.FundamentalAttributionErrorE3Q1);
			break;
		case AARScreen.Question.FundamentalAttributionErrorE3Q2:
			questionAndAnswerText = AARQuestionText.GetSelfReviewQuestionText(AARScreen.Question.FundamentalAttributionErrorE3Q2);
			break;					
		default:
			Debug.LogError("Incorrect Question Value Passed: " + question);
			return "";
		}
		
		questionAndAnswerText += " : ";
		return questionAndAnswerText;
	}	
	
}
