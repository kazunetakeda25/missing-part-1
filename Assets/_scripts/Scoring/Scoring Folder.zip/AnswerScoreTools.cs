using UnityEngine;
using System.Collections;

public class AnswerScoreTools {

	public static BiasChoice GetCorrectBiasChoice(Vignette.VignetteID vignette, SubjectData currentSubject) {
		
		BiasChoice playerChoice = BiasChoice.None;
		
		switch(vignette) {
		case Vignette.VignetteID.E1vTerrysApartmentSearch:
			playerChoice = currentSubject.E1V1BiasAnswer;
			break;
		case Vignette.VignetteID.E1vNervousElevator:
			playerChoice = currentSubject.E1V2BiasAnswer_2;
			break;
		case Vignette.VignetteID.E1vHomeOfficeSearch:
			playerChoice = currentSubject.E1V3BiasAnswer;
			break;
		case Vignette.VignetteID.E1vStephEvasive:
			playerChoice = currentSubject.E1V4BiasAnswer;
			break;
		case Vignette.VignetteID.E2vSorianoNice:
			playerChoice = currentSubject.E2V5BiasAnswer;
			break;
		case Vignette.VignetteID.E2vPressRelease:
			playerChoice = currentSubject.E2V6BiasAnswer;
			break;
		case Vignette.VignetteID.E2vGPCOfficeSearch:
			playerChoice = currentSubject.E2V7BiasAnswer;
			break;
		case Vignette.VignetteID.E3vSuspiciousMen:
			playerChoice = currentSubject.E3V8BiasAnswer;
			break;
		case Vignette.VignetteID.E3vCoupleRomance:
			playerChoice = currentSubject.E3V9BiasAnswer;
			break;
		case Vignette.VignetteID.E3vChrisBriefcaseSearch:
			playerChoice = currentSubject.E3V10BiasAnswer;
			break;
		}
		
		return playerChoice;
	}
	
}
